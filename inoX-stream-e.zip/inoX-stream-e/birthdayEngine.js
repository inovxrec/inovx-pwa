/**
 * InovX Ops — Stream E
 * Birthday Matching Logic
 *
 * Reads member_directory.json (built by syncDirectory.js), finds everyone
 * with a birthday in the next 60 days, and generates one mock "Design" task
 * per upcoming birthday — plus a 60-day calendar view.
 *
 * This script is fully independent — it only reads the local JSON file
 * your sync script already produced. No Supabase, no schema, no permissions.
 *
 * HOW TO RUN:
 *   node birthdayEngine.js
 *
 * Later (once Stream A + Stream D give you real tables), swap:
 *   - readMemberDirectory() -> supabase.from('member_directory').select()
 *   - writeGeneratedTasks()  -> supabase.from('tasks').insert(...)
 * The matching/date logic below does not need to change.
 */

const fs = require("fs");
const path = require("path");

// ---------- CONFIG ----------

const MEMBER_DIRECTORY_PATH = path.join(__dirname, "member_directory.json");
const GENERATED_TASKS_PATH = path.join(__dirname, "generated_birthday_tasks.json");

const LOOKAHEAD_DAYS = 60;

// Which sheet column holds the date of birth. Match whatever your sheet uses.
const DOB_FIELD = "dob";
const NAME_FIELD = "name";

// The domain these auto-generated tasks belong to.
const TARGET_DOMAIN = "Design";

// How many days before the birthday the task should be due
// (e.g. so the poster is ready in time).
const LEAD_TIME_DAYS = 3;

// ---------- STEP 1: READ THE MEMBER DIRECTORY ----------

function readMemberDirectory() {
  if (!fs.existsSync(MEMBER_DIRECTORY_PATH)) {
    throw new Error(
      `member_directory.json not found. Run syncDirectory.js first to generate it.`
    );
  }
  const raw = fs.readFileSync(MEMBER_DIRECTORY_PATH, "utf-8");
  const directory = JSON.parse(raw);
  return Object.values(directory); // array of member records
}

// ---------- STEP 2: DATE HELPERS ----------

// Parses a dob string (expects YYYY-MM-DD, but falls back gracefully)
// and returns { month, day } — the year doesn't matter for birthdays.
function parseMonthDay(dobString) {
  if (!dobString) return null;

  const date = new Date(dobString);
  if (isNaN(date.getTime())) {
    console.warn(`Could not parse date: "${dobString}" — skipping.`);
    return null;
  }

  return { month: date.getMonth(), day: date.getDate() };
}

// Given today's date and a person's { month, day }, returns the next
// occurrence of that birthday (this year or next year if it already passed).
function nextOccurrence(today, monthDay) {
  const { month, day } = monthDay;
  let next = new Date(today.getFullYear(), month, day);

  if (next < stripTime(today)) {
    // Birthday already happened this year — use next year's date.
    next = new Date(today.getFullYear() + 1, month, day);
  }

  return next;
}

function stripTime(date) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

function daysBetween(a, b) {
  const msPerDay = 1000 * 60 * 60 * 24;
  return Math.round((stripTime(b) - stripTime(a)) / msPerDay);
}

function addDays(date, days) {
  const result = new Date(date);
  result.setDate(result.getDate() + days);
  return result;
}

function formatDate(date) {
  return date.toISOString().split("T")[0]; // YYYY-MM-DD
}

// ---------- STEP 3: FIND UPCOMING BIRTHDAYS ----------

function findUpcomingBirthdays(members, today = new Date()) {
  const upcoming = [];

  for (const member of members) {
    const monthDay = parseMonthDay(member[DOB_FIELD]);
    if (!monthDay) continue;

    const occurrence = nextOccurrence(today, monthDay);
    const daysUntil = daysBetween(today, occurrence);

    if (daysUntil >= 0 && daysUntil <= LOOKAHEAD_DAYS) {
      upcoming.push({
        name: member[NAME_FIELD],
        external_key: member.external_key,
        birthday_date: formatDate(occurrence),
        days_until: daysUntil,
      });
    }
  }

  // Soonest birthdays first.
  upcoming.sort((a, b) => a.days_until - b.days_until);
  return upcoming;
}

// ---------- STEP 4: GENERATE ONE DESIGN TASK PER BIRTHDAY ----------

function generateBirthdayTasks(upcomingBirthdays) {
  return upcomingBirthdays.map((entry) => {
    const birthdayDate = new Date(entry.birthday_date);
    const dueDate = addDays(birthdayDate, -LEAD_TIME_DAYS);

    return {
      title: `Birthday poster — ${entry.name}`,
      description: `Design a birthday poster for ${entry.name}, due before their birthday on ${entry.birthday_date}.`,
      context_type: "domain",
      context_domain: TARGET_DOMAIN,
      due_date: formatDate(dueDate),
      state: "To Do",
      source: "recurring_rule:birthday",
      member_external_key: entry.external_key,
      birthday_date: entry.birthday_date,
    };
  });
}

// ---------- STEP 5: BUILD THE 60-DAY CALENDAR VIEW ----------

function buildCalendarView(upcomingBirthdays) {
  // Groups birthdays by date, so /calendar can just render this directly.
  const calendar = {};

  for (const entry of upcomingBirthdays) {
    if (!calendar[entry.birthday_date]) {
      calendar[entry.birthday_date] = [];
    }
    calendar[entry.birthday_date].push(entry.name);
  }

  return calendar;
}

// ---------- STEP 6: WRITE OUTPUT (STAND-IN FOR THE tasks TABLE) ----------

function writeGeneratedTasks(tasks) {
  fs.writeFileSync(GENERATED_TASKS_PATH, JSON.stringify(tasks, null, 2), "utf-8");
}

// ---------- RUN ----------

function run() {
  const members = readMemberDirectory();
  console.log(`Loaded ${members.length} member(s) from directory.`);

  const today = new Date();
  const upcoming = findUpcomingBirthdays(members, today);
  console.log(`Found ${upcoming.length} birthday(s) in the next ${LOOKAHEAD_DAYS} days.`);

  const tasks = generateBirthdayTasks(upcoming);
  writeGeneratedTasks(tasks);

  const calendar = buildCalendarView(upcoming);

  console.log("\n--- Upcoming birthdays ---");
  upcoming.forEach((entry) => {
    console.log(`${entry.birthday_date}  (${entry.days_until}d away)  —  ${entry.name}`);
  });

  console.log(`\nGenerated ${tasks.length} mock task(s) → generated_birthday_tasks.json`);
  console.log("\n--- 60-day calendar view ---");
  console.log(JSON.stringify(calendar, null, 2));
}

run();
