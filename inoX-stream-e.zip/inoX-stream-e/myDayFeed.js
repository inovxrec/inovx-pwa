/**
 * InovX Ops — Stream E
 * My Day — Merged Feed Logic
 *
 * Combines a user's domain tasks + committee tasks into one single feed,
 * sorted so the most urgent/relevant tasks surface first. This is the
 * logic behind the /myday screen.
 *
 * Fully independent — runs entirely against mock data, no Supabase needed.
 *
 * HOW TO RUN:
 *   node myDayFeed.js
 *
 * Later (once Stream D hands you the real tasks table + Stream A the
 * real domains/committees tables):
 *   - replace MOCK_TASKS with a real supabase.from('tasks').select() call,
 *     filtered to context_type/context_id the user has access to
 *   - replace MOCK_DOMAIN_MEMBERSHIPS / MOCK_COMMITTEE_MEMBERSHIPS with
 *     real membership queries
 * The merge/sort logic below does not need to change.
 */

const fs = require("fs");
const path = require("path");

const OUTPUT_PATH = path.join(__dirname, "generated_myday_feed.json");

// ---------- MOCK DATA (stand-ins for real tables) ----------

// Which domains and committees this user belongs to.
const MOCK_USER_ID = "user_meera";

const MOCK_DOMAIN_MEMBERSHIPS = ["dom_tech", "dom_design"];
const MOCK_COMMITTEE_MEMBERSHIPS = ["committee_techfest"];

// Stand-in for the tasks table — mix of domain-context and
// committee-context tasks, some assigned to our user, some not,
// covering the fields listed in MY_DAY_REQUIRED_TASK_FIELDS.
const MOCK_TASKS = [
  {
    id: "task_1",
    title: "Fix registration form bug",
    context_type: "domain",
    context_id: "dom_tech",
    due_date: "2026-09-08",
    state: "In Progress",
    priority: "high",
    assignees: ["user_meera"],
  },
  {
    id: "task_2",
    title: "Design event poster",
    context_type: "committee",
    context_id: "committee_techfest",
    due_date: "2026-09-07",
    state: "To Do",
    priority: "medium",
    assignees: ["user_meera", "user_priya"],
  },
  {
    id: "task_3",
    title: "Weekly equipment check",
    context_type: "domain",
    context_id: "dom_tech",
    due_date: "2026-09-13",
    state: "To Do",
    priority: "low",
    assignees: ["user_karthik"], // not assigned to our user
  },
  {
    id: "task_4",
    title: "Book venue for finale",
    context_type: "domain",
    context_id: "dom_events", // user is NOT in this domain
    due_date: "2026-09-09",
    state: "To Do",
    priority: "high",
    assignees: ["user_ravi"],
  },
  {
    id: "task_5",
    title: "Sponsor deck review",
    context_type: "committee",
    context_id: "committee_techfest",
    due_date: "2026-09-06",
    state: "Blocked",
    priority: "high",
    assignees: ["user_meera"],
  },
  {
    id: "task_6",
    title: "Update design tokens doc",
    context_type: "domain",
    context_id: "dom_design",
    due_date: "2026-09-20",
    state: "Done",
    priority: "low",
    assignees: [],
  },
];

// ---------- STEP 1: FILTER TO WHAT THIS USER CAN SEE ----------
// A task belongs on a user's My Day feed if:
//   - it's in a domain they're a member of, OR
//   - it's in a committee they're a member of
// (Assignment doesn't gate visibility here — being on the board's team does.
//  Assignment is used later only for sorting/highlighting "my tasks".)

function filterVisibleTasks(tasks, domainMemberships, committeeMemberships) {
  return tasks.filter((task) => {
    if (task.context_type === "domain") {
      return domainMemberships.includes(task.context_id);
    }
    if (task.context_type === "committee") {
      return committeeMemberships.includes(task.context_id);
    }
    return false;
  });
}

// ---------- STEP 2: EXCLUDE DONE/CANCELLED FROM THE ACTIVE FEED ----------
// My Day is about what's actionable today — finished work doesn't belong here.

function excludeInactiveStates(tasks) {
  const inactiveStates = ["Done", "Cancelled"];
  return tasks.filter((task) => !inactiveStates.includes(task.state));
}

// ---------- STEP 3: SORT — ASSIGNED-TO-ME FIRST, THEN SOONEST DUE, THEN PRIORITY ----------

const PRIORITY_WEIGHT = { high: 0, medium: 1, low: 2 };

function sortForMyDay(tasks, userId) {
  return [...tasks].sort((a, b) => {
    // 1. Tasks assigned to me come before tasks that aren't.
    const aMine = a.assignees.includes(userId) ? 0 : 1;
    const bMine = b.assignees.includes(userId) ? 0 : 1;
    if (aMine !== bMine) return aMine - bMine;

    // 2. Soonest due date first.
    const dateDiff = new Date(a.due_date) - new Date(b.due_date);
    if (dateDiff !== 0) return dateDiff;

    // 3. Higher priority first.
    return PRIORITY_WEIGHT[a.priority] - PRIORITY_WEIGHT[b.priority];
  });
}

// ---------- STEP 4: TAG EACH TASK WITH WHY IT'S ON THE FEED ----------
// Useful for the UI — lets the screen show a small label like
// "From: Technical" or "From: Techfest committee".

function annotateSource(tasks) {
  return tasks.map((task) => ({
    ...task,
    feed_source: task.context_type === "domain" ? `domain:${task.context_id}` : `committee:${task.context_id}`,
    is_mine: task.assignees.includes(MOCK_USER_ID),
  }));
}

// ---------- BUILD THE FEED ----------

function buildMyDayFeed(userId, domainMemberships, committeeMemberships, allTasks) {
  const visible = filterVisibleTasks(allTasks, domainMemberships, committeeMemberships);
  const active = excludeInactiveStates(visible);
  const sorted = sortForMyDay(active, userId);
  const annotated = annotateSource(sorted);
  return annotated;
}

// ---------- OUTPUT ----------

function writeFeed(feed) {
  fs.writeFileSync(OUTPUT_PATH, JSON.stringify(feed, null, 2), "utf-8");
}

// ---------- RUN ----------

function run() {
  const feed = buildMyDayFeed(
    MOCK_USER_ID,
    MOCK_DOMAIN_MEMBERSHIPS,
    MOCK_COMMITTEE_MEMBERSHIPS,
    MOCK_TASKS
  );

  writeFeed(feed);

  console.log(`Built My Day feed for ${MOCK_USER_ID}`);
  console.log(`${feed.length} task(s) visible (after filtering domain dom_events out, Done/Cancelled removed)\n`);

  feed.forEach((task, i) => {
    console.log(
      `${i + 1}. [${task.state}] ${task.title}  —  due ${task.due_date}  —  ${task.feed_source}  —  ${task.is_mine ? "assigned to me" : "team task"}`
    );
  });

  console.log(`\nWritten to: generated_myday_feed.json`);
}

run();

module.exports = { buildMyDayFeed, filterVisibleTasks, excludeInactiveStates, sortForMyDay };
