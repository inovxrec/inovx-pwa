/**
 * InovX Ops — Stream E
 * Recurring Rule Generator
 *
 * Turns a "recurring rule" definition into real task rows. Handles the four
 * assignment strategies used across the app (round-robin, fixed pool,
 * domain-lead, and data-driven — see notes below on each).
 *
 * Fully independent — runs entirely against mock data, no Supabase needed.
 *
 * HOW TO RUN:
 *   node recurringEngine.js
 *
 * Later (once Stream A + Stream D hand you the real schema):
 *   - replace MOCK_RULES with supabase.from('recurring_rules').select()
 *   - replace MOCK_EXISTING_TASKS with supabase.from('tasks').select()
 *   - replace writeGeneratedTasks() with supabase.from('tasks').insert(...)
 * The strategy logic and due-date math below do not need to change.
 */

const fs = require("fs");
const path = require("path");

// ---------- OUTPUT ----------

const GENERATED_TASKS_PATH = path.join(__dirname, "generated_recurring_tasks.json");

// ---------- MOCK DATA (stand-ins for real tables) ----------

// Stand-in for domains table — used by the "domain_lead" strategy.
const MOCK_DOMAINS = [
  { id: "dom_tech", name: "Technical", lead_user_id: "user_arjun" },
  { id: "dom_design", name: "Design", lead_user_id: "user_priya" },
  { id: "dom_events", name: "Events", lead_user_id: "user_ravi" },
];

// Stand-in for a fixed pool of users — used by "round_robin" and "fixed_pool".
const MOCK_POOL_USERS = ["user_meera", "user_karthik", "user_divya"];

// Stand-in for member_directory — used by "data_driven" (e.g. birthdays).
const MOCK_DIRECTORY = [
  { external_key: "sanjeev@gmail.com", name: "Sanjeev", dob: "2007-09-20" },
  { external_key: "madhu@gmail.com", name: "Madhu", dob: "2008-06-05" },
];

// Stand-in for existing tasks — so we don't generate duplicates for the
// same rule + due date. This is your idempotency check for recurring tasks.
let MOCK_EXISTING_TASKS = [];

// Stand-in for recurring_rules table — a few example rules covering all
// four assignment strategies. Replace with real rules once A hands them over.
const MOCK_RULES = [
  {
    id: "rule_weekly_cleanup",
    title: "Weekly equipment check",
    domain_id: "dom_tech",
    frequency: "weekly", // weekly | monthly | data_driven
    assignment_strategy: "round_robin", // round_robin | fixed_pool | domain_lead | data_driven
    assignment_pool: MOCK_POOL_USERS,
    lead_time_days: 1, // how many days before due date the task should be created
    source_type: "fixed",
  },
  {
    id: "rule_monthly_report",
    title: "Monthly attendance report",
    domain_id: "dom_events",
    frequency: "monthly",
    assignment_strategy: "domain_lead",
    assignment_pool: [],
    lead_time_days: 3,
    source_type: "fixed",
  },
  {
    id: "rule_fixed_pool_social",
    title: "Social media roundup",
    domain_id: "dom_design",
    frequency: "weekly",
    assignment_strategy: "fixed_pool",
    assignment_pool: ["user_priya"], // always the same person/people
    lead_time_days: 1,
    source_type: "fixed",
  },
  {
    id: "rule_birthday",
    title: "Birthday poster",
    domain_id: "dom_design",
    frequency: "data_driven",
    assignment_strategy: "data_driven",
    assignment_pool: [],
    lead_time_days: 3,
    source_type: "data_driven",
  },
];

// ---------- DATE HELPERS ----------

function stripTime(date) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

function addDays(date, days) {
  const result = new Date(date);
  result.setDate(result.getDate() + days);
  return result;
}

function formatDate(date) {
  return date.toISOString().split("T")[0];
}

// Computes the next due date for a fixed-frequency rule, based on today.
function computeNextDueDate(frequency, today) {
  if (frequency === "weekly") {
    return addDays(stripTime(today), 7);
  }
  if (frequency === "monthly") {
    const next = new Date(today.getFullYear(), today.getMonth() + 1, today.getDate());
    return next;
  }
  return null; // data_driven rules compute their own due dates separately
}

// ---------- ASSIGNMENT STRATEGIES ----------
// Each strategy takes the rule + some context, and returns an array of
// user IDs (or external keys, for data-driven) to assign the task to.

// 1. round_robin — cycles through the pool one person at a time,
//    based on how many tasks from this rule already exist.
function assignRoundRobin(rule, existingTasksForRule) {
  const pool = rule.assignment_pool;
  if (pool.length === 0) return [];
  const index = existingTasksForRule.length % pool.length;
  return [pool[index]];
}

// 2. fixed_pool — always assigns to the same fixed set of people.
function assignFixedPool(rule) {
  return rule.assignment_pool;
}

// 3. domain_lead — assigns to whoever leads the rule's domain.
function assignDomainLead(rule, domains) {
  const domain = domains.find((d) => d.id === rule.domain_id);
  return domain ? [domain.lead_user_id] : [];
}

// 4. data_driven — not a person-pool assignment; instead, this strategy
//    generates one task PER matching record in an external data source
//    (e.g. one birthday task per person with an upcoming birthday).
//    The actual per-record generation happens in generateDataDrivenTasks()
//    below, since it produces multiple tasks, not one assignment list.

function resolveAssignees(rule, domains, existingTasksForRule) {
  switch (rule.assignment_strategy) {
    case "round_robin":
      return assignRoundRobin(rule, existingTasksForRule);
    case "fixed_pool":
      return assignFixedPool(rule);
    case "domain_lead":
      return assignDomainLead(rule, domains);
    default:
      console.warn(`Unknown or unhandled strategy: ${rule.assignment_strategy}`);
      return [];
  }
}

// ---------- GENERATORS ----------

// Handles weekly/monthly fixed-frequency rules — one task per rule run.
function generateFixedFrequencyTask(rule, today, existingTasks, domains) {
  const dueDate = computeNextDueDate(rule.frequency, today);
  const dueDateStr = formatDate(dueDate);

  // Idempotency check: don't generate a duplicate for the same rule + due date.
  const alreadyExists = existingTasks.some(
    (t) => t.source_rule_id === rule.id && t.due_date === dueDateStr
  );
  if (alreadyExists) {
    return { task: null, skipped: true };
  }

  const existingTasksForRule = existingTasks.filter((t) => t.source_rule_id === rule.id);
  const assignees = resolveAssignees(rule, domains, existingTasksForRule);

  const task = {
    title: rule.title,
    context_type: "domain",
    context_domain_id: rule.domain_id,
    due_date: dueDateStr,
    state: "To Do",
    source_rule_id: rule.id,
    assignees,
  };

  return { task, skipped: false };
}

// Handles data-driven rules — currently just birthdays, but written generically
// so any future data-driven rule can plug in a different matcher function.
function generateDataDrivenTasks(rule, today, existingTasks, directory) {
  const generated = [];

  for (const person of directory) {
    if (!person.dob) continue;

    const dob = new Date(person.dob);
    const monthDay = { month: dob.getMonth(), day: dob.getDate() };

    let occurrence = new Date(today.getFullYear(), monthDay.month, monthDay.day);
    if (occurrence < stripTime(today)) {
      occurrence = new Date(today.getFullYear() + 1, monthDay.month, monthDay.day);
    }

    const daysUntil = Math.round((stripTime(occurrence) - stripTime(today)) / 86400000);
    const withinWindow = daysUntil >= 0 && daysUntil <= 60;
    if (!withinWindow) continue;

    const dueDate = formatDate(addDays(occurrence, -rule.lead_time_days));

    const alreadyExists = existingTasks.some(
      (t) => t.source_rule_id === rule.id && t.for_external_key === person.external_key
    );
    if (alreadyExists) continue;

    generated.push({
      title: `${rule.title} — ${person.name}`,
      context_type: "domain",
      context_domain_id: rule.domain_id,
      due_date: dueDate,
      state: "To Do",
      source_rule_id: rule.id,
      for_external_key: person.external_key,
      assignees: [], // birthdays don't auto-assign a person; left for a human to pick up
    });
  }

  return generated;
}

// ---------- OUTPUT ----------

function writeGeneratedTasks(tasks) {
  fs.writeFileSync(GENERATED_TASKS_PATH, JSON.stringify(tasks, null, 2), "utf-8");
}

// ---------- RUN ----------

function run() {
  const today = new Date();
  const allGenerated = [];
  let skippedCount = 0;

  for (const rule of MOCK_RULES) {
    if (rule.frequency === "data_driven") {
      const tasks = generateDataDrivenTasks(rule, today, MOCK_EXISTING_TASKS, MOCK_DIRECTORY);
      allGenerated.push(...tasks);
      console.log(`[${rule.id}] data-driven → generated ${tasks.length} task(s)`);
    } else {
      const { task, skipped } = generateFixedFrequencyTask(
        rule,
        today,
        MOCK_EXISTING_TASKS,
        MOCK_DOMAINS
      );
      if (skipped) {
        skippedCount++;
        console.log(`[${rule.id}] skipped — task for this due date already exists`);
      } else {
        allGenerated.push(task);
        console.log(
          `[${rule.id}] generated 1 task → due ${task.due_date}, assigned to ${task.assignees.join(", ") || "(none)"}`
        );
      }
    }
  }

  writeGeneratedTasks(allGenerated);

  console.log(`\nTotal generated: ${allGenerated.length}`);
  console.log(`Skipped (already existed): ${skippedCount}`);
  console.log(`Written to: generated_recurring_tasks.json`);
}

run();
