/**
 * InovX Ops — Stream E
 * Directory Sync Adapter
 *
 * Reads the club's public member-cards Google Sheet (published as CSV),
 * and syncs it into a local member_directory.json file.
 *
 * This script is fully independent — it needs no Supabase access, no schema,
 * and no credentials. The sheet is already public.
 *
 * HOW TO RUN:
 *   1. npm init -y
 *   2. npm install node-fetch papaparse
 *   3. Paste your published CSV URL into SHEET_CSV_URL below
 *   4. node syncDirectory.js
 *
 * Later (once Stream A gives you the real schema + Supabase access), swap
 * the readLocalDirectory()/writeLocalDirectory() functions for supabase-js
 * calls. The matching/idempotency/conflict logic below does not need to change.
 */

const fs = require("fs");
const path = require("path");
const fetch = require("node-fetch");
const Papa = require("papaparse");

// ---------- CONFIG ----------

// Paste your Google Sheet's published CSV link here.
// Get it via: File > Share > Publish to web > CSV
const SHEET_CSV_URL = "https://docs.google.com/spreadsheets/d/e/2PACX-1vTSl2kVsRBX6PIonn_7BXw6dceSo3wvU3CVVXpeEgo_vQCQAshQfe_nb3dQy1rO2_CkuW8uOCBByGuM/pub?gid=0&single=true&output=csv";

// Local "database" file, standing in for the real member_directory table.
const LOCAL_DB_PATH = path.join(__dirname, "member_directory.json");

// Which sheet column uniquely identifies a person forever.
// Change this to match whatever column your sheet actually uses
// (e.g. "email", "roll_no", "member_id").
const EXTERNAL_KEY_FIELD = "email";

// Which fields, if changed, should be flagged as a conflict rather than
// silently overwritten. Add/remove fields to match your sheet's columns.
const CONFLICT_WATCH_FIELDS = ["dob", "team", "name"];

// ---------- STEP 1: FETCH + PARSE THE SHEET ----------

async function fetchSheetRows() {
  console.log("Fetching sheet from:", SHEET_CSV_URL);
  const response = await fetch(SHEET_CSV_URL);

  if (!response.ok) {
    throw new Error(`Failed to fetch sheet: ${response.status} ${response.statusText}`);
  }

  const csvText = await response.text();

  const parsed = Papa.parse(csvText, {
    header: true,       // use the first row as column names
    skipEmptyLines: true,
    transformHeader: (h) => h.trim().toLowerCase().replace(/\s+/g, "_"),
  });

  if (parsed.errors.length > 0) {
    console.warn("CSV parse warnings:", parsed.errors);
  }

  return parsed.data; // array of row objects, e.g. { name, dob, team, email, ... }
}

// ---------- STEP 2: LOCAL "DATABASE" HELPERS ----------
// These two functions are the only thing you'll swap out for Supabase later.

function readLocalDirectory() {
  if (!fs.existsSync(LOCAL_DB_PATH)) {
    return {}; // no records yet — first run
  }
  const raw = fs.readFileSync(LOCAL_DB_PATH, "utf-8");
  return raw ? JSON.parse(raw) : {};
}

function writeLocalDirectory(directory) {
  fs.writeFileSync(LOCAL_DB_PATH, JSON.stringify(directory, null, 2), "utf-8");
}

// ---------- STEP 3: IDEMPOTENT MERGE + CONFLICT FLAGGING ----------

function mergeRowIntoDirectory(directory, incomingRow) {
  const key = incomingRow[EXTERNAL_KEY_FIELD];

  if (!key) {
    console.warn("Skipping row with no external key:", incomingRow);
    return { directory, action: "skipped" };
  }

  const existing = directory[key];

  if (!existing) {
    // New person — insert.
    directory[key] = {
      ...incomingRow,
      external_key: key,
      conflict: false,
      last_synced_at: new Date().toISOString(),
    };
    return { directory, action: "inserted" };
  }

  // Person already exists — check for conflicts on watched fields.
  const conflicts = {};
  for (const field of CONFLICT_WATCH_FIELDS) {
    const oldValue = existing[field];
    const newValue = incomingRow[field];
    if (oldValue !== undefined && newValue !== undefined && oldValue !== newValue) {
      conflicts[field] = { old: oldValue, new: newValue };
    }
  }

  const hasConflict = Object.keys(conflicts).length > 0;

  directory[key] = {
    ...existing,
    ...incomingRow, // update with latest sheet data
    external_key: key,
    conflict: hasConflict,
    conflict_details: hasConflict ? conflicts : undefined,
    last_synced_at: new Date().toISOString(),
  };

  return { directory, action: hasConflict ? "updated_with_conflict" : "updated" };
}

// ---------- STEP 4: RUN THE SYNC ----------

async function syncDirectory() {
  const rows = await fetchSheetRows();
  console.log(`Fetched ${rows.length} rows from sheet.`);

  let directory = readLocalDirectory();

  const summary = { inserted: 0, updated: 0, updated_with_conflict: 0, skipped: 0 };

  for (const row of rows) {
    const result = mergeRowIntoDirectory(directory, row);
    directory = result.directory;
    summary[result.action] = (summary[result.action] || 0) + 1;
  }

  writeLocalDirectory(directory);

  console.log("Sync complete.");
  console.log(summary);

  if (summary.updated_with_conflict > 0) {
    console.log(
      `⚠️  ${summary.updated_with_conflict} record(s) flagged with conflicts — review member_directory.json`
    );
  }
}

syncDirectory().catch((err) => {
  console.error("Sync failed:", err.message);
  process.exit(1);
});