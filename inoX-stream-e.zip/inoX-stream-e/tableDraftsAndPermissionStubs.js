/**
 * InovX Ops — Stream E
 * Table Drafts + Stubbed Permission Checks
 *
 * This file has two purposes:
 *   1. Document the exact column structure you expect for domains,
 *      committees, and committee_members — so when Stream A hands you
 *      the real schema, you can compare line-by-line instead of guessing.
 *   2. Provide a stub has_perm() function that always returns true, so
 *      your code can call permission checks NOW. When Stream B hands you
 *      the real resolver, you delete this stub and import theirs —
 *      your calling code doesn't change at all.
 *
 * Nothing in this file touches Supabase. It's pure documentation + logic.
 */

// =========================================================================
// PART 1 — TABLE DRAFTS
// =========================================================================
// These are your best-guess column lists based on the build plan's §5.
// Compare against Stream A's real schema the moment it's shared, and flag
// any mismatch in the group chat before building further on top of it.

const DRAFT_SCHEMA = {
  domains: {
    id: "uuid, primary key",
    name: "text — e.g. 'Technical', 'Design'",
    lead_user_id: "uuid, references users.id",
    visibility: "text — one of: 'private' | 'club_visible' | 'shared_with'",
    tenure_id: "uuid, references tenures.id",
  },

  committees: {
    id: "uuid, primary key",
    name: "text",
    purpose: "text",
    linked_event: "text or nullable reference — TBD with Stream A",
    start_date: "date",
    end_date: "date, nullable",
    visibility: "text — one of: 'private' | 'club_visible' | 'shared_with'",
    archived_at: "timestamp, nullable — null means active",
    tenure_id: "uuid, references tenures.id",
  },

  committee_members: {
    id: "uuid, primary key",
    committee_id: "uuid, references committees.id",
    user_id: "uuid, references users.id",
    is_coordinator: "boolean — true means admin scoped to this committee only",
    added_at: "timestamp",
  },

  recurring_rules: {
    id: "uuid, primary key",
    title: "text",
    domain_id: "uuid, references domains.id, nullable if committee-scoped",
    committee_id: "uuid, references committees.id, nullable if domain-scoped",
    frequency: "text — 'weekly' | 'monthly' | 'data_driven'",
    assignment_strategy: "text — 'round_robin' | 'fixed_pool' | 'domain_lead' | 'data_driven'",
    assignment_pool: "array of user_ids, nullable depending on strategy",
    lead_time_days: "integer",
    source_type: "text — 'fixed' | 'data_driven'",
    tenure_id: "uuid, references tenures.id",
  },

  member_directory: {
    id: "uuid, primary key",
    external_key: "text, unique — e.g. email from the public sheet",
    name: "text",
    dob: "date",
    team: "text, nullable",
    card_url: "text, nullable",
    photo_url: "text, nullable",
    conflict_flag: "boolean",
    last_synced_at: "timestamp",
  },
};

// A quick helper to print the draft schema so you can eyeball it
// or paste it into a shared doc/group chat for comparison with Stream A.
function printDraftSchema() {
  for (const [table, columns] of Object.entries(DRAFT_SCHEMA)) {
    console.log(`\nTABLE: ${table}`);
    for (const [col, desc] of Object.entries(columns)) {
      console.log(`  - ${col}: ${desc}`);
    }
  }
}

// =========================================================================
// PART 2 — STUBBED PERMISSION CHECK
// =========================================================================
// Stream B will eventually provide a real effective_permission() /
// has_perm() function backed by the database. Until then, this stub lets
// you write and test permission-gated logic without waiting.
//
// IMPORTANT: this ALWAYS returns true. It exists only so your code compiles
// and runs during development — it enforces nothing. Replace before launch.

function has_perm(userId, permissionKey) {
  console.log(`[STUB] has_perm(${userId}, "${permissionKey}") → true (not enforced yet)`);
  return true;
}

// Example of how your real code should call it — write it this way now,
// so swapping in Stream B's real resolver later is a one-line change.
function canManageCommittee(userId, committeeId) {
  // Later: import { has_perm } from './permissions.js' (Stream B's real module)
  return has_perm(userId, "committee.manage");
}

function canViewDomain(userId, domainId) {
  return has_perm(userId, "domain.view");
}

// =========================================================================
// PART 3 — MY DAY FEED FIELD LIST
// =========================================================================
// Fields your merged My Day feed query will need from the tasks table,
// even though Stream D hasn't built it yet. Share this list with D so
// they know what your feed depends on.

const MY_DAY_REQUIRED_TASK_FIELDS = [
  "id",
  "title",
  "context_type",       // 'domain' | 'committee'
  "context_id",         // the domain_id or committee_id this task belongs to
  "due_date",
  "state",               // To Do | In Progress | Submitted for Review | Done | Blocked | Cancelled
  "priority",
  "assignees",           // array of user_ids
];

// =========================================================================
// RUN — prints everything above so you can review it in one go
// =========================================================================

function run() {
  console.log("=== DRAFT SCHEMA (compare with Stream A once real schema lands) ===");
  printDraftSchema();

  console.log("\n=== STUBBED PERMISSION CHECK TEST ===");
  const allowed = canManageCommittee("user_test", "committee_123");
  console.log(`canManageCommittee result: ${allowed}`);

  console.log("\n=== MY DAY FEED — REQUIRED TASK FIELDS (share with Stream D) ===");
  console.log(MY_DAY_REQUIRED_TASK_FIELDS.join(", "));
}

run();

module.exports = {
  DRAFT_SCHEMA,
  has_perm,
  canManageCommittee,
  canViewDomain,
  MY_DAY_REQUIRED_TASK_FIELDS,
};
